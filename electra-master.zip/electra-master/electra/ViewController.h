#import <UIKit/UIKit.h>

@interface ViewController : UIViewController {
    IBOutlet UISwitch *enableTweaks;
    IBOutlet UIButton *jailbreak;
}
@end

