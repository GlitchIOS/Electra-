//
//  remap_tfp_set_hsp.h
//  electra
//
//  Created by Viktor Oreshkin on 16.01.18.
//  Copyright © 2018 Ian Beer. All rights reserved.
//

#ifndef remap_tfp_set_hsp_h
#define remap_tfp_set_hsp_h

#include <mach/mach.h>

int remap_tfp0_set_hsp4(mach_port_t *port);

#endif /* remap_tfp_set_hsp_h */
